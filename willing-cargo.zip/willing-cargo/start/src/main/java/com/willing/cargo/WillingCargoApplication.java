package com.willing.cargo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = { "com.willing.cargo", "com.alibaba.cola" })
@MapperScan("com.willing.cargo.gatewayimpl.database")
public class WillingCargoApplication {

    public static void main(String[] args) {
        SpringApplication.run(WillingCargoApplication.class, args);
    }

}
