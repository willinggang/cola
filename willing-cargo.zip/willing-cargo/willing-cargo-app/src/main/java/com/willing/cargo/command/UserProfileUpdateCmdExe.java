package com.willing.cargo.command;

import com.alibaba.cola.dto.Response;
import com.willing.cargo.convertor.UserProfileConvertor;
import com.willing.cargo.domain.user.UserProfile;
import com.willing.cargo.dto.UserProfileUpdateCmd;
import com.willing.cargo.domain.gateway.UserProfileGateway;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class UserProfileUpdateCmdExe{

    @Resource
    private UserProfileGateway userProfileGateway;

    public Response execute(UserProfileUpdateCmd cmd) {
        UserProfile userProfile = UserProfileConvertor.toEntity(cmd.getUserProfileCO());
        userProfileGateway.update(userProfile);
        return Response.buildSuccess();
    }
}