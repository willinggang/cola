package com.willing.cargo.dto;

import lombok.Data;

@Data
public class ATAMetricQry extends CommonCommand {
    public String ownerId;
}

