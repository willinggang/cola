/**
 *
 * This is the core Domain business which should be pure and clean, have no dependency over other layers.
 *
 * @author fulan.zjf
 */
package com.willing.cargo.domain;